
public class CourseGrades implements Analyzable {
	
	GradeActivity[] array = new GradeActivity [3];

	
public  void setLab(GradeActivity s , GradeActivity[]array)
{
	array[0] = s;
	
}

public void setPassFailExam(GradeActivity s,  GradeActivity[]array)
{
	array[1] = s;
}
public void setEssay (GradeActivity s, GradeActivity[]array)
{
	array[2] = s;
}

public void setFinalExam(GradeActivity s, GradeActivity[]array)
{
	array[3] = s;
}
@Override
public double getAverage(GradeActivity[]a) {
	double total = 0;
	double avg =0;
	
	for(GradeActivity s : a)
	{
		total +=s.getScore() ;
	}
	avg = (total/3);
	return avg;
}
@Override
public GradeActivity getHighest(GradeActivity []a) {
	int i;
	double max = a[0].getScore();
	GradeActivity highest = a[0];
	for(i=0;i<a.length;i++)
	{
		if((a[i].getScore())>max)
		{
			highest = a[i];
		}
	}
	return highest;
}
@Override
public GradeActivity getLowest(GradeActivity[]a) {
	int i;
	double lowest = a[0].getScore();
	GradeActivity low = a[0];
	for(i=0;i<a.length;i++)
	{
		if((a[i].getScore())>lowest)
		{
			low = a[i];
		}
	}
	return low;
	
}
}
