import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;
public class Demo extends GradeActivity  {

	
	public static void main(String[] args) {
		
		GradeActivity []array = new GradeActivity[3];
		Scanner scn = new Scanner(System.in);
		
		double score = 0;
		
		System.out.println("Enter Lab Grade");
		score = scn.nextDouble();
		GradeActivity s = new GradeActivity(score);
		s.setLab(s, array);
		System.out.println("Enter exam Grade");
		score = scn.nextDouble();
		s.setScore(score);
		System.out.println("Enter essay Grade");
		score = scn.nextDouble();
		s.setScore(score);
		s.setEssay(s, array);
		System.out.println("Enter Final exam Grade");
		s.setScore(score);
		s.setFinalExam(s, array);
		/*
		 * 
		 * 
		 * 
		 */
		
	      
	       String fileName = "CourseGrade.dat";
	       
	       System.out.println("Log: Serialization begins....");
	       serialize(array, fileName);
	       System.out.println("Log: Serialization ended succesfully....");
	       
	       array = null;
	       System.out.println("Log: Deserialization begins....");
	       array = deserialize(fileName, array);
	       System.out.println("Log: Serialization ended succesfully....");
	       
	       int count = 1;
	       for (GradeActivity b : array)
	       {
	           System.out.printf(" %d: %.3f\n", count, b.getScore());
	       }
	           
	    }
	    
		//@Overload method of Serialize (Not used on the main method)
	    
	    
	    private static void serialize(GradeActivity []array, String fileName) 
	            throws IOException
	    {
	        if (fileName == null && fileName.length() <= 0)
	            throw new IllegalArgumentException(fileName);
	        
	        if(array == null || array.size() <= 0)
	            throw new IllegalArgumentException("List of BankAccount cannot be empty");
	        
	         ObjectOutputStream ostream  = null;
	        try
	        {
//	            FileOutputStream fstream = 
//	                    new FileOutputStream("BankAccountDat.dat");
	            ostream = new ObjectOutputStream(new FileOutputStream(fileName));
	            
	            ostream.writeObject(array); //does the serialization
	        }
	        catch(IOException e)
	        {
	            throw e;
	        }
	        catch(Exception ex)
	        {
	            throw ex;
	        }
	        finally{
	            if(ostream != null)
	            {
	                ostream.close();
	            }
	        }
	    }
	    
	    
	    private static GradeActivity[] deserialize(String fileName, GradeActivity []a) 
	            throws IOException, Exception
	    {
	    	GradeActivity[] b = new GradeActivity[3];
	        if (fileName == null && fileName.length() <= 0)
	            throw new IllegalArgumentException(fileName);
	        
	        ObjectInputStream istream = null;
	       
	        try
	        {
	            istream = new ObjectInputStream(
	                            new FileInputStream(fileName));
	            a[0] =()istream.readObject();
	            a[1] =(b[1])istream.readObject();
	        }
	        catch(IOException e)
	        {
	            throw e;
	        }
	        catch(Exception ex)
	        {
	            throw ex;
	        }
	        finally{
	            if(istream != null)
	                istream.close();
	        }
	        
	        return a;
	    }
	}
	}

}
