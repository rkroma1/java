
public class GradeActivity extends CourseGrades{
	private double score;
	
	GradeActivity()
	{
		setScore(0);
	}
	
	GradeActivity(double s)
	{
		setScore(s);
	}
	
	public double getScore() {
		return score;
	}
	
	public void setScore(double score) {
		this.score = score;
	}
}
