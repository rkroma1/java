
public interface Analyzable {
	
	double getAverage(GradeActivity[] a);
	GradeActivity getHighest(GradeActivity[] a);
	GradeActivity getLowest(GradeActivity[] a);


}
